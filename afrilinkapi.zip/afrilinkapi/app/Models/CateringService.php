<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CateringService extends Model

{
  
    protected $table = 'catering_services';
    protected $fillable = ['name', 'num_member', 'num_girl', 'num_boy','address', 'ifu', 'user_id' ];

     // Define the relationship with the User model (belongs to a User)
     public function user()
     {
         return $this->belongsTo(User::class, 'user_id');
     }
}
