<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EventTicket extends Model
{
    use HasFactory;
    protected $table = 'events_tickets';

    protected $fillable = [
        'name',
        'type',
        'price',
        'total',
        'solded',
        'available',
        'event_id',
        'buyer_id',
        'purchase_date',
        'status',
    ];

    // Relationships
    public function event()
    {
        return $this->belongsTo(Event::class, 'event_id');
    }

    public function buyer()
    {
        return $this->belongsTo(User::class, 'buyer_id');
    }
}
