<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Vehicule extends Model
{
    use HasFactory;
    protected $table = 'vehicule';

    protected $fillable = [
        'name', 'type', 'description', 'image', 'Lone_delay', 'price', 'availability', 'rides_sharing_id',
    ];

    // Define the relationship between MenuPrice and Restaurant models
    public function vehicule()
    {
        return $this->belongsTo(Restaurant::class, 'rides_sharing_id');
    }
}
