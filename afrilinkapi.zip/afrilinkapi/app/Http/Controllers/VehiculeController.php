<?php

namespace App\Http\Controllers;

use App\Models\Vehicule;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Validator;

class VehiculeController extends Controller
{
    public function index()
    {
        $vehicles = Vehicule::all();
        return response()->json($vehicles);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'type' => 'required|string|max:255',
            'description' => 'required|string', // Ensure description is required
            'image' => 'required|string|max:255',
            'Lone_delay' => 'nullable|string',
            'price' => 'required|numeric',
            'availability' => 'required|boolean',
            'rides_sharing_id' => 'required|exists:rides_sharing,id',
        ]);
    
        if ($validator->fails()) {
            return response()->json(['error' => 'Validation failed', 'details' => $validator->errors()], Response::HTTP_BAD_REQUEST);
        }
    
        $vehicleData = $request->all();
    
        $vehicle = Vehicule::create($vehicleData);
    
        return response()->json(['message' => 'Vehicle created successfully', 'data' => $vehicle]);
    }
    

    public function show($id)
    {
        $vehicle = Vehicule::find($id);

        if (!$vehicle) {
            return response()->json(['error' => 'Vehicle not found'], Response::HTTP_NOT_FOUND);
        }

        return response()->json($vehicle);
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'type' => 'required|string|max:255',
            'description' => 'required|string',
            'image' => 'required|string|max:255',
            'Lone_delay' => 'nullable|string',
            'price' => 'required|numeric',
            'availability' => 'required|boolean',
            'rides_sharing_id' => 'required|exists:rides_sharing,id',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => 'Validation failed', 'details' => $validator->errors()], Response::HTTP_BAD_REQUEST);
        }

        $vehicle = Vehicule::find($id);

        if (!$vehicle) {
            return response()->json(['error' => 'Vehicle not found'], Response::HTTP_NOT_FOUND);
        }

        $vehicle->update($request->all());

        return response()->json(['message' => 'Vehicle updated successfully', 'data' => $vehicle]);
    }

    public function destroy($id)
    {
        $vehicle = Vehicule::find($id);

        if (!$vehicle) {
            return response()->json(['error' => 'Vehicle not found'], Response::HTTP_NOT_FOUND);
        }

        $vehicle->delete();

        return response()->json(['message' => 'Vehicle deleted successfully'], Response::HTTP_OK);
    }
}
