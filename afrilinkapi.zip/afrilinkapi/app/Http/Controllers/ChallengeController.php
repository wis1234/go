<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Challenge;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class ChallengeController extends Controller
{
    public function index()
    {
        $challenges = Challenge::all();
        return response()->json(['data' => $challenges], 200);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string',
            'description' => 'required|string',
            'delay' => 'required|string',
            'awards' => 'nullable|string',
            'starts_at' => 'required|date',
            'ends_at' => 'required|date|after:starts_at',
            'appreciation' => 'nullable|string',
            'event_id' => 'required|exists:events,id',
            'creator_id' => 'required|exists:users,id',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $challenge = Challenge::create($request->all());

        return response()->json(['message' => 'Challenge created successfully', 'data' => $challenge], 201);
    }

    public function show($id)
    {
        try {
            $challenge = Challenge::findOrFail($id);
            return response()->json(['data' => $challenge], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['message' => 'Challenge not found'], 404);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $challenge = Challenge::findOrFail($id);

            $validator = Validator::make($request->all(), [
                'name' => 'required|string',
                'description' => 'required|string',
                'delay' => 'required|string',
                'awards' => 'nullable|string',
                'starts_at' => 'required|date',
                'ends_at' => 'required|date|after:starts_at',
                'appreciation' => 'nullable|string',
                'event_id' => 'required|exists:events,id',
                'creator_id' => 'required|exists:users,id',
            ]);

            if ($validator->fails()) {
                return response()->json(['errors' => $validator->errors()], 422);
            }

            $challenge->update($request->all());

            return response()->json(['message' => 'Challenge updated successfully', 'data' => $challenge], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['message' => 'Challenge not found'], 404);
        }
    }

    public function destroy($id)
    {
        try {
            $challenge = Challenge::findOrFail($id);
            $challenge->delete();

            return response()->json(['message' => 'Challenge deleted successfully'], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['message' => 'Challenge not found'], 404);
        }
    }
}
