<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ChallengeParticipant;

class ChallengeParticipantController extends Controller
{
    public function index()
    {
        $challengeParticipants = ChallengeParticipant::all();
        return response()->json($challengeParticipants);
    }

    public function store(Request $request)
    {
        $request->validate([
            'user_id' => 'required|integer',
            'event_id' => 'required|integer',
            'challenge_id' => 'required|integer',
            'appreciation' => 'required|string',
            'result' => 'required|string',
            'opinion' => 'required|string',
        ]);

        $challengeParticipant = ChallengeParticipant::create($request->all());
        return response()->json($challengeParticipant, 201);
    }

    public function show($id)
    {
        $challengeParticipant = ChallengeParticipant::find($id);
        if (!$challengeParticipant) {
            return response()->json(['message' => 'Challenge participant not found'], 404);
        }
        return response()->json($challengeParticipant);
    }

    public function update(Request $request, $id)
    {
        $challengeParticipant = ChallengeParticipant::find($id);
        if (!$challengeParticipant) {
            return response()->json(['message' => 'Challenge participant not found'], 404);
        }

        $request->validate([
            'user_id' => 'required|integer',
            'event_id' => 'required|integer',
            'challenge_id' => 'required|integer',
            'appreciation' => 'required|string',
            'result' => 'required|string',
            'opinion' => 'required|string',
        ]);

        $challengeParticipant->update($request->all());
        return response()->json($challengeParticipant);
    }

    public function destroy($id)
    {
        $challengeParticipant = ChallengeParticipant::find($id);
        if (!$challengeParticipant) {
            return response()->json(['message' => 'Challenge participant not found'], 404);
        }
        $challengeParticipant->delete();
        return response()->json(['message' => 'Challenge participant deleted successfully']);
    }
}
