<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\EventParticipant;

class EventParticipantController extends Controller
{
    public function index()
    {
        $participants = EventParticipant::all();
        return response()->json($participants);
    }

    public function store(Request $request)
    {
        $request->validate([
            'user_id' => 'required|integer',
            'event_id' => 'required|integer',
            'opinion' => 'nullable|string',
        ]);

        $participant = EventParticipant::create($request->all());
        return response()->json($participant, 201);
    }

    public function show($id)
    {
        $participant = EventParticipant::find($id);
        if (!$participant) {
            return response()->json(['message' => 'Participant not found'], 404);
        }
        return response()->json($participant);
    }

    public function update(Request $request, $id)
    {
        $participant = EventParticipant::find($id);
        if (!$participant) {
            return response()->json(['message' => 'Participant not found'], 404);
        }

        $request->validate([
            'user_id' => 'required|integer',
            'event_id' => 'required|integer',
            'opinion' => 'nullable|string',
        ]);

        $participant->update($request->all());
        return response()->json($participant);
    }

    public function destroy($id)
    {
        $participant = EventParticipant::find($id);
        if (!$participant) {
            return response()->json(['message' => 'Participant not found'], 404);
        }

        $participant->delete();
        return response()->json(['message' => 'Participant deleted successfully']);
    }
}
