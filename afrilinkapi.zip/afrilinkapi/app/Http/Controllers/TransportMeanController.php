<?php

namespace App\Http\Controllers;

use App\Models\TransportMean;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Validator;

class TransportMeanController extends Controller
{
    public function index()
    {
        $transportMeans = TransportMean::all();
        return response()->json($transportMeans);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'type' => 'required|string|max:255',
            'description' => 'required|string',
            'departure_country' => 'required|string|max:255',
            'departure_city' => 'required|string|max:255',
            'departure_date' => 'required|date',
            'departure_time' => 'required|date_format:H:i:s',
            'destination_country' => 'required|string|max:255',
            'destination_city' => 'required|string|max:255',
            'destination_date' => 'required|date',
            'destination_time' => 'required|date_format:H:i:s',
            'price' => 'required|numeric',
            'travel_agency_id' => 'required|exists:travel_agencies,id',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => 'Validation failed', 'details' => $validator->errors()], Response::HTTP_BAD_REQUEST);
        }

        $transportMeanData = $request->all();

        $transportMean = TransportMean::create($transportMeanData);

        return response()->json(['message' => 'Transport mean created successfully', 'data' => $transportMean]);
    }

    public function show($id)
    {
        $transportMean = TransportMean::find($id);

        if (!$transportMean) {
            return response()->json(['error' => 'Transport mean not found'], Response::HTTP_NOT_FOUND);
        }

        return response()->json($transportMean);
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'type' => 'required|string|max:255',
            'description' => 'required|string',
            'departure_country' => 'required|string|max:255',
            'departure_city' => 'required|string|max:255',
            'departure_date' => 'required|date',
            'departure_time' => 'required|date_format:H:i:s',
            'destination_country' => 'required|string|max:255',
            'destination_city' => 'required|string|max:255',
            'destination_date' => 'required|date',
            'destination_time' => 'required|date_format:H:i:s',
            'price' => 'required|numeric',
            'travel_agency_id' => 'required|exists:travel_agencies,id',
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => 'Validation failed', 'details' => $validator->errors()], Response::HTTP_BAD_REQUEST);
        }

        $transportMean = TransportMean::find($id);

        if (!$transportMean) {
            return response()->json(['error' => 'Transport mean not found'], Response::HTTP_NOT_FOUND);
        }

        $transportMean->update($request->all());

        return response()->json(['message' => 'Transport mean updated successfully', 'data' => $transportMean]);
    }

    public function destroy($id)
    {
        $transportMean = TransportMean::find($id);

        if (!$transportMean) {
            return response()->json(['error' => 'Transport mean not found'], Response::HTTP_NOT_FOUND);
        }

        $transportMean->delete();

        return response()->json(['message' => 'Transport mean deleted successfully'], Response::HTTP_OK);
    }
}
