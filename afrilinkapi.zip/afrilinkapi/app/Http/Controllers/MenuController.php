<?php

namespace App\Http\Controllers;

use App\Models\Menu;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class MenuController extends Controller
{
    public function index()
    {
        $menu = Menu::all();
        return response()->json($menu);
    }

    public function store(Request $request)
    {
        try {
            $validator = Validator::make($request->only(['name', 'price', ' availablity', 'restaurant_id']), [
                'name' => 'required|string',
                'price' => 'required|string',
                'availability' => 'string',
                'restaurant_id' => 'required|exists:restaurants,id',
            ]);

            if ($validator->fails()) {
                throw new ValidationException($validator);
            }

            $menu = Menu::create($request->only(['name','price','availability', 'restaurant_id']));

            return response()->json(['message' => 'Menu created successfully', 'data' => $menu]);
        } catch (ValidationException $e) {
            return response()->json(['error' => $e->getMessage()], Response::HTTP_BAD_REQUEST);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while creating the menu'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function show($id)
    {
        try {
            $menu = Menu::findOrFail($id);
            return response()->json($menu);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Menu not found'], Response::HTTP_NOT_FOUND);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while fetching the menu'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $validator = Validator::make($request->only(['name','price', 'availability', 'restaurant_id']), [
                'name' => 'required|string',
                'price' => 'required|string',
                'availability' => 'required|string',
                'restaurant_id' => 'required|exists:restaurants,id',
            ]);

            if ($validator->fails()) {
                throw new ValidationException($validator);
            }

            $menu = Menu::findOrFail($id);
            $menu->update($request->only(['name', 'price', ' availability', 'restaurant_id']));

            return response()->json(['message' => 'Menu updated successfully', 'data' => $menu]);
        } catch (ValidationException $e) {
            return response()->json(['error' => $e->getMessage()], Response::HTTP_BAD_REQUEST);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Menu not found'], Response::HTTP_NOT_FOUND);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while updating the menu'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function destroy($id)
    {
        try {
            $menu = Menu::findOrFail($id);
            $menu->delete();

            return response()->json(['message' => 'Menu deleted successfully'], Response::HTTP_OK);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Menu not found'], Response::HTTP_NOT_FOUND);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while deleting the menu'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
