<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\EventTicket;

class EventTicketController extends Controller
{
    public function index()
    {
        $eventTickets = EventTicket::all();
        return response()->json($eventTickets);
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'type' => 'required',
            'price' => 'required|numeric',
            'total' => 'required|integer',
            'event_id' => 'required|exists:events,id',
        ]);

        $eventTicket = EventTicket::create($request->all());
        return response()->json($eventTicket, 201);
    }

    public function show($id)
    {
        $eventTicket = EventTicket::find($id);
        if (!$eventTicket) {
            return response()->json(['message' => 'Event ticket not found'], 404);
        }
        return response()->json($eventTicket);
    }

    public function update(Request $request, $id)
    {
        $eventTicket = EventTicket::find($id);
        if (!$eventTicket) {
            return response()->json(['message' => 'Event ticket not found'], 404);
        }

        $this->validate($request, [
            'name' => 'required',
            'type' => 'required',
            'price' => 'required|numeric',
            'total' => 'required|integer',
            'event_id' => 'required|exists:events,id',
        ]);

        $eventTicket->update($request->all());
        return response()->json($eventTicket);
    }

    public function destroy($id)
    {
        $eventTicket = EventTicket::find($id);
        if (!$eventTicket) {
            return response()->json(['message' => 'Event ticket not found'], 404);
        }
        $eventTicket->delete();
        return response()->json(['message' => 'Event ticket deleted successfully']);
    }
}
