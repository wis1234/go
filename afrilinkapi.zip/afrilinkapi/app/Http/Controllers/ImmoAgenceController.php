<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ImmoAgence;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpFoundation\Response;

class ImmoAgenceController extends Controller
{
    public function index()
    {
        $agences = ImmoAgence::all();
        return response()->json($agences);
    }

    public function store(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'name' => 'required|string|max:255',
                'address' => 'required|string|max:255',
                'city' => 'required|string|max:255',
                'website' => 'required|string|max:255',
                'user_id' => 'required|exists:users,id',
                
            ]);

            if ($validator->fails()) {
                throw new ValidationException($validator);
            }

            // Encrypt the password before storing it in the database
            $encryptedPassword = Hash::make($request->input('password'));

            $agenceData = $request->except('password'); // Exclude the password from the response data
            $agence = ImmoAgence::create(array_merge($agenceData, ['password' => $encryptedPassword]));
            return response()->json($agence, Response::HTTP_CREATED);
        } catch (ValidationException $e) {
            return response()->json(['error' => $e->getMessage()], Response::HTTP_BAD_REQUEST);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while creating the immo agence.'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function show($id)
    {
        try {
            $agence = ImmoAgence::findOrFail($id);
            return response()->json($agence);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Immo agence not found.'], Response::HTTP_NOT_FOUND);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while fetching the immo agence.'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $validator = Validator::make($request->all(), [
                'name' => 'required|string|max:255',
                'address' => 'required|string|max:255',
                'city' => 'required|string|max:255',
                'website' => 'required|string|max:255',
                'user_id' => 'required|exists:users,id',
            ]);

            if ($validator->fails()) {
                throw new ValidationException($validator);
            }

            $agence = ImmoAgence::findOrFail($id);
            $agence->update($request->all());
            return response()->json($agence);
        } catch (ValidationException $e) {
            return response()->json(['error' => $e->getMessage()], Response::HTTP_BAD_REQUEST);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Immo agence not found.'], Response::HTTP_NOT_FOUND);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while updating the immo agence.'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function destroy($id)
    {
        try {
            $agence = ImmoAgence::findOrFail($id);
            $agence->delete();

            return response()->json(['message' => 'Immo agence deleted successfully.'], Response::HTTP_OK);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Immo agence not found.'], Response::HTTP_NOT_FOUND);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while deleting the immo agence.'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
