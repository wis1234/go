<?php

namespace App\Http\Controllers;

use App\Models\RidesSharing;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class RidesSharingController extends Controller
{
    public function index()
    {
        $ridesSharing = RidesSharing::all();
        return response()->json($ridesSharing);
    }

    public function store(Request $request)
    {
        try {
            $validator = Validator::make($request->only(['name', 'address', 'city', 'website', 'user_id']), [
                'name' => 'required|string|max:255',
                'address' => 'required|string|max:255',
                'city' => 'required|string|max:255',
                'website' => 'nullable|string|max:255',
                'user_id' => 'required|exists:users,id',
            ]);

            if ($validator->fails()) {
                throw new ValidationException($validator);
            }

            $ridesSharing = RidesSharing::create($request->only(['name', 'address', 'city', 'website', 'user_id']));

            return response()->json(['message' => 'Rides sharing created successfully', 'data' => $ridesSharing]);
        } catch (ValidationException $e) {
            return response()->json(['error' => $e->getMessage()], Response::HTTP_BAD_REQUEST);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while creating the rides sharing'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function show($id)
    {
        try {
            $ridesSharing = RidesSharing::findOrFail($id);
            return response()->json($ridesSharing);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Rides sharing not found'], Response::HTTP_NOT_FOUND);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while fetching the rides sharing'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $validator = Validator::make($request->only(['name', 'address', 'city', 'website', 'user_id']), [
                'name' => 'required|string|max:255',
                'address' => 'required|string|max:255',
                'city' => 'required|string|max:255',
                'website' => 'nullable|string|max:255',
                'user_id' => 'required|exists:users,id',
            ]);

            if ($validator->fails()) {
                throw new ValidationException($validator);
            }

            $ridesSharing = RidesSharing::findOrFail($id);
            $ridesSharing->update($request->only(['name', 'address', 'city', 'website', 'user_id']));

            return response()->json(['message' => 'Rides sharing updated successfully', 'data' => $ridesSharing]);
        } catch (ValidationException $e) {
            return response()->json(['error' => $e->getMessage()], Response::HTTP_BAD_REQUEST);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Rides sharing not found'], Response::HTTP_NOT_FOUND);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while updating the rides sharing'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function destroy($id)
    {
        try {
            $ridesSharing = RidesSharing::findOrFail($id);
            $ridesSharing->delete();

            return response()->json(['message' => 'Rides sharing deleted successfully'], Response::HTTP_OK);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Rides sharing not found'], Response::HTTP_NOT_FOUND);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while deleting the rides sharing'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
