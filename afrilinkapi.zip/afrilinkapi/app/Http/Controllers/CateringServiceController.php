<?php

namespace App\Http\Controllers;

use App\Models\CateringService;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class CateringServiceController extends Controller
{
    /**
     * Display a listing of the catering services.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cateringServices = CateringService::all();
        return response()->json($cateringServices);
    }

    /**
     * Store a newly created catering service in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'num_member' => 'required|integer',
            'num_girl' => 'required|integer',
            'num_boy' => 'required|integer',
            'address' => 'required|string|max:255',
            'ifu' => 'required|string|max:255',
            'user_id' => 'required|exists:users,id', // Assuming the "users" table has an "id" column.
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], Response::HTTP_BAD_REQUEST);
        }

        $cateringService = CateringService::create($request->all());

        return response()->json(['message' => 'Catering service created successfully', 'data' => $cateringService]);
    }

    /**
     * Display the specified catering service.
     *
     * @param  \App\Models\CateringService  $cateringService
     * @return \Illuminate\Http\Response
     */
    public function show(CateringService $cateringService)
    {
        return response()->json($cateringService);
    }

    /**
     * Update the specified catering service in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\CateringService  $cateringService
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CateringService $cateringService)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'num_member' => 'required|integer',
            'num_girl' => 'required|integer',
            'num_boy' => 'required|integer',
            'address' => 'required|string|max:255',
            'ifu' => 'required|string|max:255',
            'user_id' => 'required|exists:users,id', // Assuming the "users" table has an "id" column.
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], Response::HTTP_BAD_REQUEST);
        }

        try {
            $cateringService->update($request->all());
            return response()->json(['message' => 'Catering service updated successfully', 'data' => $cateringService]);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Catering service not found'], Response::HTTP_NOT_FOUND);
        }
    }

    /**
     * Remove the specified catering service from storage.
     *
     * @param  \App\Models\CateringService  $cateringService
     * @return \Illuminate\Http\Response
     */
    public function destroy(CateringService $cateringService)
    {
        try {
            $cateringService->delete();
            return response()->json(['message' => 'Catering service deleted successfully']);
        } catch (NotFoundHttpException $e) {
            return response()->json(['error' => 'Catering service not found'], Response::HTTP_NOT_FOUND);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Something went wrong'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
