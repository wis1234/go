<?php

namespace App\Http\Controllers;

use App\Models\Drink;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class DrinkController extends Controller
{
    public function index()
    {
        $drink = Drink::all();
        return response()->json($drink);
    }

    public function store(Request $request)
    {
        try {
            $validator = Validator::make($request->only(['name', ' price', ' availablity', 'restaurant_id']), [
                'name' => 'required|string',
                'price' => '|string',
                'availability' => '|string',
                'restaurant_id' => 'required|exists:restaurants,id',
            ]);

            if ($validator->fails()) {
                throw new ValidationException($validator);
            }

            $drink = Drink::create($request->only(['name','price','availability', 'restaurant_id']));

            return response()->json(['message' => 'Drink created successfully', 'data' => $drink]);
        } catch (ValidationException $e) {
            return response()->json(['error' => $e->getMessage()], Response::HTTP_BAD_REQUEST);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while creating the drink'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function show($id)
    {
        try {
            $drink = Drink::findOrFail($id);
            return response()->json($drink);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Drink not found'], Response::HTTP_NOT_FOUND);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while fetching the drink'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $validator = Validator::make($request->only(['name','price', 'availability', 'restaurant_id']), [
                'name' => 'required|string',
                'price' => 'required|string',
                'availability' => 'required|string',
                'restaurant_id' => 'required|exists:restaurants,id',
            ]);

            if ($validator->fails()) {
                throw new ValidationException($validator);
            }

            $drink = Drink::findOrFail($id);
            $drink->update($request->only(['name', 'price', ' availability', 'restaurant_id']));

            return response()->json(['message' => 'Drink updated successfully', 'data' => $drink]);
        } catch (ValidationException $e) {
            return response()->json(['error' => $e->getMessage()], Response::HTTP_BAD_REQUEST);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Drink not found'], Response::HTTP_NOT_FOUND);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while updating the drink'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function destroy($id)
    {
        try {
            $drink = Drink::findOrFail($id);
            $drink->delete();

            return response()->json(['message' => 'Drink deleted successfully'], Response::HTTP_OK);
        } catch (ModelNotFoundException $e) {
            return response()->json(['error' => 'Drink not found'], Response::HTTP_NOT_FOUND);
        } catch (\Exception $e) {
            return response()->json(['error' => 'An error occurred while deleting the drink'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
