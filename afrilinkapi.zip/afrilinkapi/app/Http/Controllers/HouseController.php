<?php


namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\House;

class HouseController extends Controller
{
    public function index()
    {
        $houses = House::all();
        return response()->json(['data' => $houses], 200);
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'address' => 'required',
            'city' => 'required',
            'state' => 'required',
            'country' => 'required',
            'num_bedrooms' => 'required|integer',
            'num_bathrooms' => 'required|integer',
            'num_livingrooms' => 'required|integer',
            'num_apartments' => 'required|integer',
            'price' => 'required',
            'type' => 'required',
            'apartments_type' => 'required',
            'property_type' => 'required',
            'area' => 'required|numeric',
            'image' => 'required',
            'description' => 'required',
            'immo_agence_id' => 'required|exists:immo_agences,id',
        ]);

        $house = House::create($request->all());

        return response()->json(['data' => $house], 201);
    }

    public function show($id)
    {
        $house = House::find($id);

        if (!$house) {
            return response()->json(['message' => 'House not found'], 404);
        }

        return response()->json(['data' => $house], 200);
    }

    public function update(Request $request, $id)
    {
        $house = House::find($id);

        if (!$house) {
            return response()->json(['message' => 'House not found'], 404);
        }

        $request->validate([
            'name' => 'required',
            'address' => 'required',
            'city' => 'required',
            'state' => 'required',
            'country' => 'required',
            'num_bedrooms' => 'required|integer',
            'num_bathrooms' => 'required|integer',
            'num_livingrooms' => 'required|integer',
            'num_apartments' => 'required|integer',
            'price' => 'required',
            'type' => 'required',
            'apartments_type' => 'required',
            'property_type' => 'required',
            'area' => 'required|numeric',
            'image' => 'required',
            'description' => 'required',
            'immo_agence_id' => 'required|exists:immo_agences,id',
        ]);

        $house->update($request->all());

        return response()->json(['data' => $house], 200);
    }

    public function destroy($id)
    {
        $house = House::find($id);

        if (!$house) {
            return response()->json(['message' => 'House not found'], 404);
        }

        $house->delete();

        return response()->json(['message' => 'House deleted successfully'], 200);
    }
}

