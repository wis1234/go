<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Apartment;

class ApartmentController extends Controller
{
    public function index()
    {
        $apartments = Apartment::all();
        return response()->json($apartments);
    }

    public function store(Request $request)
    {
        $request->validate([
            'type' => 'required',
            'address' => 'required',
            'num_bedrooms' => 'required|integer',
            'num_bathrooms' => 'required|integer',
            'num_livingrooms' => 'required|integer',
            'description' => 'required',
            'price' => 'required|numeric',
        ]);

        $apartment = Apartment::create($request->all());
        return response()->json($apartment, 201);
    }

    public function show($id)
    {
        $apartment = Apartment::find($id);
        if (!$apartment) {
            return response()->json(['message' => 'Apartment not found'], 404);
        }
        return response()->json($apartment);
    }

    public function update(Request $request, $id)
    {
        $apartment = Apartment::find($id);
        if (!$apartment) {
            return response()->json(['message' => 'Apartment not found'], 404);
        }

        $request->validate([
            'type' => 'required',
            'address' => 'required',
            'num_bedrooms' => 'required|integer',
            'num_bathrooms' => 'required|integer',
            'num_livingrooms' => 'required|integer',
            'description' => 'required',
            'price' => 'required|numeric',
        ]);

        $apartment->update($request->all());
        return response()->json($apartment);
    }

    public function destroy($id)
    {
        $apartment = Apartment::find($id);
        if (!$apartment) {
            return response()->json(['message' => 'Apartment not found'], 404);
        }
        $apartment->delete();
        return response()->json(['message' => 'Apartment deleted successfully']);
    }
}
